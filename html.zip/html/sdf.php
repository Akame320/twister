<?php if( have_rows('rewiews') ): ?>
    <?php while( have_rows('rewiews') ): the_row(); ?>
        <div class="home-reviews__slide">
            <div class="home-reviews-card">
                <div class="home-reviews-card__head">
                    <div class="home-reviews-card__name">Малышева О. С.</div>
                    <div class="home-reviews-card__date"><?php echo get_sub_field('Date'); ?></div>
                    <div class="home-reviews-card__place"><?php echo get_sub_field('city'); ?></div>
                </div>
                <div class="home-reviews-card__text"><?php echo get_sub_field('comment'); ?></div>
            </div>
        </div>
    <?php endwhile; ?>
<?php endif; ?>